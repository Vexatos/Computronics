package appeng.api.exceptions;

public class RecipeError extends Exception
{

	private static final long serialVersionUID = -6602870588617670262L;

	public RecipeError(String n) {
		super( n );
	}

}
