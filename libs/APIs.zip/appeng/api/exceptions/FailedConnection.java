package appeng.api.exceptions;

public class FailedConnection extends Exception
{

	private static final long serialVersionUID = -2544208090248293753L;

	public FailedConnection() {
	}
}
