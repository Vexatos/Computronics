package appeng.api.exceptions;

public class RegistrationError extends Exception
{

	private static final long serialVersionUID = -6602870588617670263L;

	public RegistrationError(String n) {
		super( n );
	}

}
