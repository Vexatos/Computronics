package appeng.api.exceptions;

public class ModNotInstalled extends Exception
{

	private static final long serialVersionUID = -9052435206368425494L;

	public ModNotInstalled(String t) {
		super( t );
	}

}
