package appeng.api.parts;

public enum LayerFlags
{

	IC2_ENET

}
