package appeng.api.parts;

public interface IBoxProvider
{

	/**
	 * add your collision information to the the list.
	 * 
	 * @param boxes
	 */
	void getBoxes(IPartCollsionHelper bch);

}
