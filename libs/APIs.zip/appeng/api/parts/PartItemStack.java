package appeng.api.parts;

public enum PartItemStack
{
	Pick,

	Break,

	Wrench,

	Network,

	World
}
