package appeng.api.parts;

public enum BusSupport
{
	CABLE,

	DENSE_CABLE,

	NO_PARTS
}
