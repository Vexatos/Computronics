package appeng.api.parts;


public interface ISimplifiedBundle
{

}
