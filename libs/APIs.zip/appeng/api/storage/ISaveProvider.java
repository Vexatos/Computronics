package appeng.api.storage;


public interface ISaveProvider
{

	void saveChanges(IMEInventory cellInventory);

}
