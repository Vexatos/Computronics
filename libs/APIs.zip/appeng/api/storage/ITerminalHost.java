package appeng.api.storage;

import appeng.api.util.IConfigureableObject;

public interface ITerminalHost extends IStorageMonitorable, IConfigureableObject
{

}
