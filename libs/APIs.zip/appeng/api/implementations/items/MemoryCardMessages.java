package appeng.api.implementations.items;

/**
 * Status Results for use with {@link IMemoryCard}
 */
public enum MemoryCardMessages
{
	INVALID_MACHINE, SETTINGS_LOADED, SETTINGS_SAVED, SETTINGS_CLEARED
}
