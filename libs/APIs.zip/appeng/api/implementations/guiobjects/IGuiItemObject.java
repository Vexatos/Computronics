package appeng.api.implementations.guiobjects;

import net.minecraft.item.ItemStack;

public interface IGuiItemObject
{

	public ItemStack getItemStack();
}
