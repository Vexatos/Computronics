package appeng.api.implementations.tiles;

import appeng.api.networking.energy.IEnergySource;

public interface IMEChest extends IChestOrDrive, ITileStorageMonitorable, IEnergySource
{

}
