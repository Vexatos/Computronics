package appeng.api.config;

public enum IncludeExclude
{
	WHITELIST, BLACKLIST
}