package appeng.api.config;

public enum OperationMode
{
	FILL, EMPTY
}