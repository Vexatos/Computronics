package appeng.api.config;

public enum ViewItems
{
	ALL, STORED, CRAFTABLE
}