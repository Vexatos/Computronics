package appeng.api.config;

public enum NetworkEmitterMode
{

	POWER_LEVEL,

	BOOTING,

	CHANNEL_ERROR

}