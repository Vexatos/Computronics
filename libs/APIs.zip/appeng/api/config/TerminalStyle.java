package appeng.api.config;

public enum TerminalStyle
{

	TALL,

	FULL,

	SMALL

}