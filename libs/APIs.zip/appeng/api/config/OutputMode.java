package appeng.api.config;

public enum OutputMode
{
	EXPORT_ONLY, EXPORT_OR_CRAFT, CRAFT_ONLY
}
