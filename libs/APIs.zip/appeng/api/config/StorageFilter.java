package appeng.api.config;

public enum StorageFilter
{

	NONE,

	EXTACTABLE_ONLY

}
