package appeng.api.config;

public enum LevelType
{

	ITEM_LEVEL,

	ENERGY_LEVEL

}