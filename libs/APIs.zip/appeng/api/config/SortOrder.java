package appeng.api.config;

public enum SortOrder
{
	NAME, AMOUNT, MOD, INVTWEAKS
}