package appeng.api.config;

public enum SearchBoxMode
{
	AUTOSEARCH, MANUAL_SEARCH, NEI_AUTOSEARCH, NEI_MANUAL_SEARCH
}
