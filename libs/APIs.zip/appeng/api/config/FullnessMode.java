package appeng.api.config;

public enum FullnessMode
{
	EMPTY, HALF, FULL
}