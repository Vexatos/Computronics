package appeng.api.config;

public enum RelativeDirection
{
	LEFT, RIGHT, UP, DOW
}