package appeng.api.config;


public enum CondenserOuput
{

	TRASH, // 0

	MATTER_BALLS, // 256

	SINGULARITY; // 250,000

	public int requiredPower = 0;

}