package appeng.api.config;

public enum ModSettings
{

}
