package appeng.api.config;

public enum CopyMode
{
	CLEAR_ON_REMOVE, KEEP_ON_REMOVE
}
