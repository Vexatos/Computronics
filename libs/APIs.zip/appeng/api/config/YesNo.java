package appeng.api.config;

public enum YesNo
{
	YES, NO, UNDECIDED
}
