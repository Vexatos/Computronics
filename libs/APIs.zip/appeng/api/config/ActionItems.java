package appeng.api.config;

public enum ActionItems
{
	WRENCH, CLOSE, STASH, ENCODE, SUBSTITUTION
}