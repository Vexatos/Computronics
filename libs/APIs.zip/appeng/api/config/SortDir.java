package appeng.api.config;

public enum SortDir
{
	ASCENDING, DESCENDING;
}