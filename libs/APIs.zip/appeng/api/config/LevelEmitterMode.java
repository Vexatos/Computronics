package appeng.api.config;

public enum LevelEmitterMode
{

	STORED_AMOUNT,

	STOREABLE_AMOUNT

}