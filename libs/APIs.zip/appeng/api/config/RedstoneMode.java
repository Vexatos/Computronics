package appeng.api.config;

public enum RedstoneMode
{
	IGNORE, LOW_SIGNAL, HIGH_SIGNAL, SIGNAL_PULSE
}