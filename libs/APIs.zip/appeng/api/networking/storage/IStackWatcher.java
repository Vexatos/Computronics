package appeng.api.networking.storage;

import java.util.Collection;

import appeng.api.storage.data.IAEStack;

public interface IStackWatcher extends Collection<IAEStack>
{

}
