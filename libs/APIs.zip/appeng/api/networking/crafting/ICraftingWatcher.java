package appeng.api.networking.crafting;

import java.util.Collection;

import appeng.api.storage.data.IAEStack;

public interface ICraftingWatcher extends Collection<IAEStack>
{

}
