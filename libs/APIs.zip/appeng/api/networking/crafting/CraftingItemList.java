package appeng.api.networking.crafting;

public enum CraftingItemList
{
	ALL, STORAGE, ACTIVE, PENDING
}
