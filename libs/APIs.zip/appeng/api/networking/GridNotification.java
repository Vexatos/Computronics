package appeng.api.networking;

public enum GridNotification
{
	/**
	 * the visible connections for this node have changed, useful for cable.
	 */
	ConnectionsChanged,
}
