package appeng.api.networking.security;

public class BaseActionSource
{

	public boolean isPlayer()
	{
		return false;
	}

	public boolean isMachine()
	{
		return false;
	}

}
