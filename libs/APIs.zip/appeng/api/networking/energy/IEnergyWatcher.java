package appeng.api.networking.energy;

import java.util.Collection;

public interface IEnergyWatcher extends Collection<Double>
{

}
