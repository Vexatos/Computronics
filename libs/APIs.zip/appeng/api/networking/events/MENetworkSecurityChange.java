package appeng.api.networking.events;

/**
 * Posted by the security framework when permissions change
 */
public class MENetworkSecurityChange extends MENetworkEvent
{

}
