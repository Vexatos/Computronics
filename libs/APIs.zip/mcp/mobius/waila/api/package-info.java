@API(apiVersion="1.0",owner="Waila",provides="WailaAPI")
package mcp.mobius.waila.api;
import cpw.mods.fml.common.API;