/**
 * Copyright (c) 2011-2014, SpaceToad and the BuildCraft Team
 * http://www.mod-buildcraft.com
 *
 * BuildCraft is distributed under the terms of the Minecraft Mod Public
 * License 1.0, or MMPL. Please check the contents of the license located in
 * http://www.mod-buildcraft.com/MMPL-1.0.txt
 */
package buildcraft.api.fuels;

import java.util.HashMap;
import java.util.Map;

import net.minecraft.block.Block;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

import net.minecraftforge.fluids.Fluid;
import net.minecraftforge.fluids.FluidStack;

import buildcraft.api.core.StackKey;

public final class IronEngineCoolant {

	public static Map<String, Coolant> liquidCoolants = new HashMap<String, Coolant>();
	public static Map<StackKey, FluidStack> solidCoolants = new HashMap<StackKey, FluidStack>();

	private IronEngineCoolant() {
	}

	public static FluidStack getFluidCoolant(ItemStack stack) {
		return solidCoolants.get(new StackKey(stack));
	}

	public static Coolant getCoolant(ItemStack stack) {
		return getCoolant(getFluidCoolant(stack));
	}

	public static Coolant getCoolant(FluidStack fluidStack) {
		return fluidStack != null && fluidStack.getFluid() != null ? liquidCoolants.get(fluidStack.getFluid().getName()) : null;
	}

	public interface Coolant {

		float getDegreesCoolingPerMB(float currentHeat);
	}

	public static void addCoolant(final Fluid fluid, final float degreesCoolingPerMB) {
		if (fluid != null) {
			liquidCoolants.put(fluid.getName(), new Coolant() {
				@Override
				public float getDegreesCoolingPerMB(float currentHeat) {
					return degreesCoolingPerMB;
				}
			});
		}
	}

	/**
	 * Adds a solid coolant like Ice Blocks. The FluidStack must contain a registered
	 * Coolant Fluid or nothing will happen. You do not need to call this for
	 * Fluid Containers.
	 *
	 * @param stack
	 * @param coolant
	 */
	public static void addCoolant(final ItemStack stack, final FluidStack coolant) {
		if (stack != null && stack.getItem() != null && coolant != null) {
			solidCoolants.put(new StackKey(stack), coolant);
		}
	}

	/**
	 * Adds a solid coolant like Ice Blocks. The FluidStack must contain a
	 * registered Coolant Fluid or nothing will happen. You do not need to call
	 * this for Fluid Containers.
	 * 
	 * @param item
	 * @param coolant
	 */
	public static void addCoolant(final Item item, final int metadata, final FluidStack coolant) {
		addCoolant(new ItemStack(item, 1, metadata), coolant);
	}

	public static void addCoolant(final Block block, final int metadata, final FluidStack coolant) {
		addCoolant(new ItemStack(block, 1, metadata), coolant);
	}

	public static boolean isCoolant(Fluid fluid) {
		return liquidCoolants.containsKey(fluid.getName());
	}
}
