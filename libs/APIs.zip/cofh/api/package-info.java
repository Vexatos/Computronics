/**
 * (C) 2014 Team CoFH / CoFH / Cult of the Full Hub
 * http://www.teamcofh.com
 */
@API(apiVersion = CoFHAPIProps.VERSION, owner = "CoFHLib", provides = "CoFHAPI")
package cofh.api;

import cpw.mods.fml.common.API;

