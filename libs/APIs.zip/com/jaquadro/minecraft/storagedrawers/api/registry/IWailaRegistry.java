package com.jaquadro.minecraft.storagedrawers.api.registry;

public interface IWailaRegistry
{
    void registerTooltipHandler (IWailaTooltipHandler handler);
}
