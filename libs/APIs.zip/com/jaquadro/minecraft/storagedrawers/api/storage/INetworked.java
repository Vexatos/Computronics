package com.jaquadro.minecraft.storagedrawers.api.storage;

public interface INetworked
{
}
