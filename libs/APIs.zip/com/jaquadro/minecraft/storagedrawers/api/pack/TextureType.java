package com.jaquadro.minecraft.storagedrawers.api.pack;

public enum TextureType
{
    Front1,
    Front2,
    Front4,
    Side,
    SideSort,
    SideVSplit,
    SideHSplit,
    TrimBorder,
    TrimBlock
}
