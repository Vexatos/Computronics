package com.jaquadro.minecraft.storagedrawers.api.pack;

public enum BlockType
{
    Drawers,
    DrawersSorting,
    Trim
}
