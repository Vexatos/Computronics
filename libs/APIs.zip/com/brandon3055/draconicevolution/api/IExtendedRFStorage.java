package com.brandon3055.draconicevolution.api;

/**
 * Created by Brandon on 6/03/2015.
 */
public interface IExtendedRFStorage
{
	double getEnergyStored();

	double getMaxEnergyStored();
}
