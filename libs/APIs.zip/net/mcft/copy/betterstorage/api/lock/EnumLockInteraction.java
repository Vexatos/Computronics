package net.mcft.copy.betterstorage.api.lock;

public enum EnumLockInteraction {
	
	OPEN,
	PICK,
	ATTACK
	
}
