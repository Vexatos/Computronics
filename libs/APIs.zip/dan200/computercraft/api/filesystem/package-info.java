/**
 * This file is part of the public ComputerCraft API - http://www.computercraft.info
 * Copyright Daniel Ratcliffe, 2011-2014. This API may be redistributed unmodified and in full only.
 * For help using the API, and posting your mods, visit the forums at computercraft.info.
 */

@API( owner="ComputerCraft", provides="ComputerCraft|API|FileSystem", apiVersion="1.64" )
package dan200.computercraft.api.filesystem;

import cpw.mods.fml.common.API;