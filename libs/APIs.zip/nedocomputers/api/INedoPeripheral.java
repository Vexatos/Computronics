package nedocomputers.api;

public interface INedoPeripheral {
	boolean connectable(int side);
	short busRead(int addr);
	void busWrite(int addr, short data);
	int getBusId();
	void setBusId(int id);
}
